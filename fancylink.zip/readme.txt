=== Fancylink ===
Contributors:      Garrett Massey < www.garrettmassey.net >
Tags:              link, block, custom block
Tested up to:      6.1
Stable tag:        0.1.0
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A custom block for Gutenberg that allows you to create a fancy link.

== Description ==

Create small interactive and "fancy" links that can be used in the Wordpress Block Editor. The links are slightly animated on hover.

I will likely never regularly update this repository, so if you have any issues, please feel free to fork it and make it your own. I just wanted a quick way to create a specific style in the block editor myself.